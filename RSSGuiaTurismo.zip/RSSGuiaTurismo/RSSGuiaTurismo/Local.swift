//
//  Local.swift
//  RSSGuiaTurismo
//
//  Created by Usuário Convidado on 18/11/15.
//  Copyright © 2015 7MOB. All rights reserved.
//

import Foundation
import CoreData

class Local: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
